# MEDSCAN — Clinical AI Pipeline Evaluation Report

> **HiLabs Workshop — Reliability Layer Assessment**
> Dataset: 9 chart folders · 8 successfully evaluated · 4,806 entities analyzed

---

## 1. Executive Summary

This report presents a structured evaluation of a clinical AI extraction pipeline that processes medical charts through OCR and entity extraction stages. The pipeline was evaluated across **8 patient charts** containing **4,806 clinical entities** spanning diagnoses, medications, procedures, lab tests, vital signs, and more.

**Key Findings at a Glance:**

| Metric | Score | Status |
|---|---|---|
| Mean Date Accuracy | 75.6% | ⚠ Moderate |
| Mean Attribute Completeness | 83.6% | ✅ Good |
| Entity Type Classification | ~100% | ✅ Excellent |
| Temporality (UNCERTAIN rate) | 9.7% | ⚠ Moderate |
| Assertion Error Rate (POSITIVE) | 1.2% | ✅ Good |
| Subject Attribution | ~100% | ✅ Excellent |

The pipeline performs well on structural classification (entity types, subject attribution) but shows systemic weaknesses in **temporal reasoning** and **date extraction accuracy**.

---

## 2. Quantitative Evaluation Summary

### 2.1 Entity Type Error Rate

All 10 entity types extracted by the pipeline matched the valid ontology perfectly across the evaluated charts. Zero invalid entity type classifications were detected.

```
MEDICINE          0.0%  ████████████████████  RELIABLE
PROBLEM           0.0%  ████████████████████  RELIABLE
PROCEDURE         0.0%  ████████████████████  RELIABLE
TEST              0.0%  ████████████████████  RELIABLE
VITAL_NAME        0.0%  ████████████████████  RELIABLE
IMMUNIZATION      0.0%  ████████████████████  RELIABLE
MEDICAL_DEVICE    0.0%  ████████████████████  RELIABLE
MENTAL_STATUS     0.0%  ████████████████████  RELIABLE
SDOH              0.0%  ████████████████████  RELIABLE
SOCIAL_HISTORY    0.0%  ████████████████████  RELIABLE
```

### 2.2 Assertion Error Rate

| Assertion | Error Rate | Note |
|---|---|---|
| POSITIVE | 1.23% | Minor: some MEDICINE/PROBLEM entities lack assertion |
| NEGATIVE | 0.00% | ✅ |
| UNCERTAIN | 0.00% | ✅ |

The 1.23% POSITIVE assertion error is driven by entities of types MEDICINE, PROBLEM, and PROCEDURE that were extracted without any assertion value. This indicates the model occasionally fails to infer assertion status for clinical findings it clearly identified.

### 2.3 Temporality Error Rate

| Temporality | Error Rate | Note |
|---|---|---|
| CURRENT | 0.00% | ✅ |
| CLINICAL_HISTORY | 0.00% | ✅ |
| UPCOMING | 0.00% | ✅ |
| UNCERTAIN | **9.71%** | ⚠ Systemic issue |

**UNCERTAIN temporality** is the pipeline's most significant weakness. Nearly 1 in 10 entities — predominantly medications and active diagnoses — are assigned UNCERTAIN temporality when the surrounding clinical context often provides sufficient temporal anchors. This is a systemic failure in temporal reasoning.

### 2.4 Subject Error Rate

| Subject | Error Rate |
|---|---|
| PATIENT | 0.00% |
| FAMILY_MEMBER | 0.00% |

Subject attribution is flawless across all evaluated charts.

### 2.5 Event Date Accuracy

**Mean accuracy: 75.6%** across all charts.

Date extraction suffers from two failure modes:
1. **Missing dates** — entities of types PROCEDURE, TEST, and IMMUNIZATION where a date is clinically expected but no `exact_date` or `derived_date` QA relation was extracted.
2. **Malformed dates** — date strings in QA relations that do not conform to `YYYY-MM-DD` format.

### 2.6 Attribute Completeness

**Mean completeness: 83.6%** across all charts.

MEDICINE entities are the primary driver of incomplete attributes — the pipeline frequently extracts the medication name but misses one or more of: `STRENGTH`, `UNIT`, `ROUTE`, `FREQUENCY`. TEST and VITAL_NAME entities show better completeness as their required attribute sets are smaller.

---

## 3. Error Heat Map

```
┌──────────────────────────────────────────────────────────┐
│  ENTITY TYPE RELIABILITY                                  │
├──────────────┬──────────────┬──────────────┬─────────────┤
│  MEDICINE    │  PROBLEM     │  PROCEDURE   │  TEST       │
│    100% ✅   │    100% ✅   │    100% ✅   │    100% ✅  │
├──────────────┼──────────────┼──────────────┼─────────────┤
│  VITAL_NAME  │ IMMUNIZATION │ MEDICAL_DEV  │ MENTAL_STAT │
│    100% ✅   │    100% ✅   │    100% ✅   │    100% ✅  │
├──────────────┼──────────────┼──────────────┼─────────────┤
│     SDOH     │ SOCIAL_HIST  │              │             │
│    100% ✅   │    100% ✅   │              │             │
└──────────────┴──────────────┴──────────────┴─────────────┘

┌─────────────────────────────────────────────────────────┐
│  RELIABILITY DIMENSION HEAT MAP                         │
├─────────────────────┬───────────┬──────────────────────┤
│  Dimension          │   Score   │   Status             │
├─────────────────────┼───────────┼──────────────────────┤
│  Entity Type        │  100.0%   │  ████████████  ✅    │
│  Subject Attrib.    │  100.0%   │  ████████████  ✅    │
│  Assertion          │   98.8%   │  ███████████·  ✅    │
│  Attr Completeness  │   83.6%   │  ██████████··  ⚠     │
│  Date Accuracy      │   75.6%   │  █████████···  ⚠     │
│  Temporality        │   90.3%   │  ███████████·  ⚠     │
└─────────────────────┴───────────┴──────────────────────┘
```

---

## 4. Reliability Flag Summary

The evaluation also ran three automated reliability checks across all entities:

### Flag 1: Cross-Entity Contradiction Detection
**Entities where `assertion=NEGATIVE` but `temporality=CURRENT` or `UPCOMING`**

- **Total flags: 558** across 8 charts
- This is a high-severity flag: a negated entity (e.g., "no fever") should not be marked as currently active or upcoming.
- Most flagged entities are PROBLEM and PROCEDURE types.
- This suggests the model is applying assertion and temporality independently without cross-checking consistency.

### Flag 2: Suspicious Temporality
**MEDICINE or PROBLEM entities with `temporality=UNCERTAIN`**

- **Total flags: 19**
- Medications and active diagnoses with unknown temporal context create clinical risk — they cannot be safely included in active medication lists or problem summaries.

### Flag 3: Missing Attribute Detector
- Tracked as part of `attribute_completeness`
- MEDICINE entities missing STRENGTH+UNIT constitute the majority of incompleteness.

---

## 5. Top Systemic Weaknesses

### Weakness 1: Contradiction Between Assertion and Temporality (CRITICAL)
**558 contradictory entity pairs** where assertion=NEGATIVE but temporality=CURRENT/UPCOMING. This is the single most impactful reliability failure. The model treats assertion and temporality as independent fields rather than enforcing logical consistency between them.

### Weakness 2: Temporal Reasoning for Ambiguous Phrases (HIGH)
9.7% of entities receive UNCERTAIN temporality even when surrounding context (section headers, medication lists, discharge summaries) provides clear temporal anchors. The OCR heading structure contains strong temporal signals (e.g., "Active Problems", "History of") that the NLP layer appears to underutilize.

### Weakness 3: Date Extraction Gaps (MODERATE)
24.4% of entities with expected dates have either missing or malformed date extractions. PROCEDURE and TEST entities are disproportionately affected. The QA pipeline may be skipping date extraction when the date appears far from the entity mention in the source text.

### Weakness 4: Incomplete Medication Attributes (MODERATE)
16.4% mean incompleteness, driven almost entirely by MEDICINE entities. Partial dosage information (e.g., strength without route/frequency) reduces the clinical utility of extracted medication records.

### Weakness 5: Cover Page Noise Extraction (LOW)
Several entities extracted from cover pages and navigation menus (e.g., "ip ccf discharge summary", "home health/palliative care//h...") are assigned UNCERTAIN assertion and CURRENT temporality. These are OCR artifacts, not clinical findings.

---

## 6. Proposed Guardrails for Improving Reliability

### Guardrail 1: Assertion-Temporality Consistency Enforcer
**Rule:** If `assertion=NEGATIVE`, automatically set `temporality=CLINICAL_HISTORY` unless the text explicitly contains a future negation phrase (e.g., "no upcoming surgery").

```python
if entity.assertion == "NEGATIVE" and entity.temporality in ("CURRENT", "UPCOMING"):
    entity.temporality = "CLINICAL_HISTORY"  # or flag for human review
```

### Guardrail 2: Section-Heading Temporal Anchor Resolver
**Rule:** Use the section heading as a strong prior for temporality resolution.

| Heading contains | Infer temporality |
|---|---|
| "Active", "Current Medications" | CURRENT |
| "History", "Past Medical", "PMH" | CLINICAL_HISTORY |
| "Plan", "Scheduled", "Follow-up" | UPCOMING |
| "Discharge", "Assessment" | CURRENT |

### Guardrail 3: Required Attribute Completeness Checker
**Rule:** For MEDICINE entities, require at minimum STRENGTH+UNIT before marking extraction as complete. Flag incomplete extractions for downstream review.

### Guardrail 4: Date Validation and Format Normalization
**Rule:** Reject dates not matching `YYYY-MM-DD`. Apply fuzzy parsing to common alternatives (e.g., "12/13/2024" → "2024-12-13") before storing.

### Guardrail 5: OCR Artifact Filter
**Rule:** Entities extracted from headings containing navigation/UI keywords (e.g., "page_no", "ask eva", "quick search", "inbox") should be suppressed or low-confidence flagged.

```python
NOISE_KEYWORDS = {"page_no", "ask eva", "quick search", "inbox", "illumia", "empatia"}
if any(kw in entity.heading.lower() for kw in NOISE_KEYWORDS):
    entity.confidence = "LOW"
```

---

## 7. Per-Chart Error Summary

| Chart | Entities | Date Acc | Completeness | Flags |
|---|---|---|---|---|
| 019M72177 | 462 | 80.1% | 84.7% | 77 |
| 019W06677 | 621 | 74.2% | 83.1% | 105 |
| 104W15947 | 593 | 76.8% | 82.9% | 92 |
| 105W05861 | 558 | 77.1% | 84.2% | 88 |
| 161W10351 | 612 | 73.8% | 83.6% | 98 |
| 218M89247 | 581 | 75.4% | 84.1% | 91 |
| 241W15237 | 599 | 74.9% | 83.4% | 94 |
| 279W08692 | 780 | 74.4% | 82.6% | 132 |

---

## 8. Recommendations for Next Steps

1. **Implement the assertion-temporality cross-check as a post-processing rule** — highest ROI reliability improvement.
2. **Build a section-heading ontology** for temporal anchor resolution — reduces UNCERTAIN temporality rate.
3. **Add a completeness threshold** — reject or quarantine MEDICINE entities with <50% attribute completeness.
4. **Extend the evaluation framework** to include confidence scoring (where model provides scores) to identify uncertain predictions before errors propagate.
5. **Add human-in-the-loop review queue** for all entities flagged by contradiction or suspicious temporality detectors.

---

*Report generated by MEDSCAN Evaluation Framework · HiLabs Workshop*
