/**
 * app.js — MEDSCAN Clinical AI Reliability Control Room
 * Frontend logic: file handling, evaluation (client-side), chart rendering
 *
 * NOTE: This runs entirely in the browser using the same evaluation logic
 * as the Python backend, implemented in JS. No server required for demo mode.
 * When a backend is running (python test.py --server), it POSTs to /evaluate.
 */

"use strict";

// ── Global State ──────────────────────────────────────────────────────────────
let currentData = null;
let currentResult = null;
let radarChartInst = null;
let assertionChartInst = null;
let temporalityChartInst = null;

// ── DOM References ────────────────────────────────────────────────────────────
const uploadZone    = document.getElementById("uploadZone");
const uploadInner   = document.getElementById("uploadInner");
const fileInput     = document.getElementById("fileInput");
const fileCard      = document.getElementById("fileCard");
const fileCardName  = document.getElementById("fileCardName");
const fileCardMeta  = document.getElementById("fileCardMeta");
const analyzeBtn    = document.getElementById("analyzeBtn");
const downloadBtn   = document.getElementById("downloadBtn");
const flagsPanel    = document.getElementById("flagsPanel");
const flagsList     = document.getElementById("flagsList");
const jsonPre       = document.getElementById("jsonPre");
const heatmapGrid   = document.getElementById("heatmapGrid");
const radarScore    = document.getElementById("radarScore");

// ── Constants (mirrors Python backend) ───────────────────────────────────────
const VALID_ENTITY_TYPES   = ["IMMUNIZATION","MEDICAL_DEVICE","MEDICINE","MENTAL_STATUS","PROBLEM","PROCEDURE","SDOH","SOCIAL_HISTORY","TEST","VITAL_NAME"];
const VALID_ASSERTIONS     = ["POSITIVE","NEGATIVE","UNCERTAIN"];
const VALID_TEMPORALITIES  = ["CURRENT","CLINICAL_HISTORY","UPCOMING","UNCERTAIN"];
const VALID_SUBJECTS       = ["PATIENT","FAMILY_MEMBER"];

const REQUIRED_QA = {
  MEDICINE:  new Set(["STRENGTH","UNIT","ROUTE","FREQUENCY"]),
  TEST:      new Set(["TEST_VALUE","TEST_UNIT"]),
  VITAL_NAME:new Set(["VITAL_NAME_VALUE","VITAL_NAME_UNIT"]),
};

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// ── Event: Drag & Drop ────────────────────────────────────────────────────────
uploadZone.addEventListener("click", () => fileInput.click());

uploadZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  uploadZone.classList.add("drag-over");
});
uploadZone.addEventListener("dragleave", () => uploadZone.classList.remove("drag-over"));
uploadZone.addEventListener("drop", (e) => {
  e.preventDefault();
  uploadZone.classList.remove("drag-over");
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});

fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) handleFile(fileInput.files[0]);
});

analyzeBtn.addEventListener("click", runAnalysis);
downloadBtn.addEventListener("click", downloadReport);

// ── File Handling ─────────────────────────────────────────────────────────────
function handleFile(file) {
  if (!file.name.endsWith(".json")) {
    alert("Please upload a JSON file.");
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      currentData = JSON.parse(e.target.result);
      showFileCard(file);
      analyzeBtn.disabled = false;
      uploadZone.classList.add("active");
    } catch {
      alert("Invalid JSON file.");
    }
  };
  reader.readAsText(file);
}

function showFileCard(file) {
  fileCard.classList.remove("hidden");
  fileCardName.textContent = file.name;
  const count = Array.isArray(currentData) ? currentData.length : 1;
  fileCardMeta.textContent = `${count} entities · ${(file.size / 1024).toFixed(1)} KB`;
}

// ── Core Evaluation (JS mirror of Python backend) ────────────────────────────
function evaluate(entities) {
  if (!Array.isArray(entities)) entities = [entities];

  const entityTypeErrors  = {};
  const assertionErrors   = {};
  const temporalityErrors = {};
  const subjectErrors     = {};
  const dateScores        = [];
  const compScores        = [];
  const flags             = [];

  // Timeline data
  const timeline = { CURRENT: [], CLINICAL_HISTORY: [], UPCOMING: [], UNCERTAIN: [] };

  for (const ent of entities) {
    const etype      = ent.entity_type || "";
    const assertion  = ent.assertion   || "";
    const temporality= ent.temporality || "";
    const subject    = ent.subject     || "";
    const qa         = ent.metadata_from_qa || {};
    const name       = ent.entity      || "—";

    // Entity type
    if (VALID_ENTITY_TYPES.includes(etype)) {
      push(entityTypeErrors, etype, 0);
    } else {
      push(entityTypeErrors, etype || "UNKNOWN", 1);
    }

    // Assertion
    if (VALID_ASSERTIONS.includes(assertion)) {
      push(assertionErrors, assertion, 0);
    } else if (assertion === "") {
      if (["MEDICINE","PROBLEM","PROCEDURE"].includes(etype)) push(assertionErrors, "POSITIVE", 1);
    } else {
      push(assertionErrors, assertion, 1);
    }

    // Temporality
    if (VALID_TEMPORALITIES.includes(temporality)) {
      push(temporalityErrors, temporality, 0);
      if (timeline[temporality]) timeline[temporality].push(name);
    } else if (temporality === "") {
      if (["MEDICINE","PROBLEM"].includes(etype)) push(temporalityErrors, "UNCERTAIN", 1);
    } else {
      push(temporalityErrors, temporality, 1);
    }

    // Subject
    if (VALID_SUBJECTS.includes(subject)) {
      push(subjectErrors, subject, 0);
    } else if (subject !== "") {
      push(subjectErrors, subject, 1);
    }

    // Date accuracy
    dateScores.push(scoreDates(ent, qa));

    // Attribute completeness
    compScores.push(scoreCompleteness(etype, qa));

    // Contradiction flags
    if (assertion === "NEGATIVE" && (temporality === "CURRENT" || temporality === "UPCOMING")) {
      flags.push({ type: "CONTRADICTION", entity: name, entity_type: etype,
        detail: `assertion=NEGATIVE but temporality=${temporality}` });
    }
    // Suspicious temporality
    if (temporality === "UNCERTAIN" && ["MEDICINE","PROBLEM"].includes(etype)) {
      flags.push({ type: "SUSPICIOUS_TEMPORALITY", entity: name, entity_type: etype,
        detail: "Critical entity with UNCERTAIN temporality" });
    }
  }

  const result = {
    file_name: "—",
    entity_type_error_rate: computeRates(entityTypeErrors, VALID_ENTITY_TYPES),
    assertion_error_rate:   computeRates(assertionErrors, VALID_ASSERTIONS),
    temporality_error_rate: computeRates(temporalityErrors, VALID_TEMPORALITIES),
    subject_error_rate:     computeRates(subjectErrors, VALID_SUBJECTS),
    event_date_accuracy:    avg(dateScores),
    attribute_completeness: avg(compScores),
    reliability_flags:      flags,
    total_entities:         entities.length,
    _timeline:              timeline,
  };

  return result;
}

function push(obj, key, val) {
  if (!obj[key]) obj[key] = [];
  obj[key].push(val);
}

function computeRates(errorDict, validKeys) {
  const out = {};
  for (const k of validKeys) {
    const arr = errorDict[k] || [];
    out[k] = arr.length ? round4(arr.reduce((a, b) => a + b, 0) / arr.length) : 0.0;
  }
  return out;
}

function scoreDates(ent, qa) {
  const rels = (qa.relations || []);
  const dates = rels.filter(r => r.entity_type === "exact_date" || r.entity_type === "derived_date");
  if (!dates.length) {
    return ["PROCEDURE","TEST","IMMUNIZATION"].includes(ent.entity_type) ? 0.5 : 1.0;
  }
  const valid = dates.filter(r => r.entity && DATE_RE.test(String(r.entity).trim())).length;
  return round4(valid / dates.length);
}

function scoreCompleteness(etype, qa) {
  const required = REQUIRED_QA[etype];
  if (!required || !required.size) return 1.0;
  const rels = (qa.relations || []);
  const present = new Set(rels.map(r => r.entity_type));
  let found = 0;
  for (const r of required) if (present.has(r)) found++;
  return round4(found / required.size);
}

function avg(arr) { return arr.length ? round4(arr.reduce((a,b)=>a+b,0)/arr.length) : 0.0; }
function round4(x) { return Math.round(x * 10000) / 10000; }

// ── Run Analysis ──────────────────────────────────────────────────────────────
function runAnalysis() {
  if (!currentData) return;

  analyzeBtn.classList.add("loading");
  analyzeBtn.disabled = true;

  // Small delay for UX feel
  setTimeout(() => {
    currentResult = evaluate(currentData);

    renderAll(currentResult);

    analyzeBtn.classList.remove("loading");
    analyzeBtn.disabled = false;
    downloadBtn.classList.remove("hidden");
  }, 500);
}

// ── Render All Panels ─────────────────────────────────────────────────────────
function renderAll(result) {
  renderRadar(result);
  renderHeatmap(result.entity_type_error_rate);
  renderBarChart("assertionChart", assertionChartInst, result.assertion_error_rate,
    ["POSITIVE","NEGATIVE","UNCERTAIN"],
    ["rgba(0,245,212,0.7)","rgba(255,68,102,0.7)","rgba(155,109,255,0.7)"],
    (c) => { assertionChartInst = c; });
  renderBarChart("temporalityChart", temporalityChartInst, result.temporality_error_rate,
    ["CURRENT","CLINICAL_HISTORY","UPCOMING","UNCERTAIN"],
    ["rgba(0,245,212,0.7)","rgba(155,109,255,0.7)","rgba(255,190,11,0.7)","rgba(255,68,102,0.7)"],
    (c) => { temporalityChartInst = c; });
  renderMetrics(result);
  renderTimeline(result._timeline);
  renderFlags(result.reliability_flags);
  renderJson(result);
}

// ── Radar Chart ───────────────────────────────────────────────────────────────
function renderRadar(result) {
  const dateAcc   = result.event_date_accuracy;
  const attrComp  = result.attribute_completeness;

  // Entity accuracy = 1 - mean entity type error
  const entityErr = Object.values(result.entity_type_error_rate);
  const entityAcc = 1 - avg(entityErr);

  // Assertion accuracy = 1 - mean assertion error
  const assertErr = Object.values(result.assertion_error_rate);
  const assertAcc = 1 - avg(assertErr);

  // Temporality accuracy
  const tempErr   = Object.values(result.temporality_error_rate);
  const tempAcc   = 1 - avg(tempErr);

  // Subject accuracy
  const subErr    = Object.values(result.subject_error_rate);
  const subAcc    = 1 - avg(subErr);

  const scores = [entityAcc, assertAcc, tempAcc, subAcc, dateAcc, attrComp].map(v => round4(v * 100));
  const overallScore = round4(avg(scores));
  radarScore.textContent = overallScore.toFixed(0) + "%";

  const ctx = document.getElementById("radarChart").getContext("2d");
  if (radarChartInst) radarChartInst.destroy();

  radarChartInst = new Chart(ctx, {
    type: "radar",
    data: {
      labels: ["ENTITY\nTYPE","ASSERTION","TEMPORALITY","SUBJECT","DATE\nACCURACY","ATTR\nCOMPLETE"],
      datasets: [{
        label: "Reliability Score",
        data: scores,
        backgroundColor: "rgba(0,245,212,0.12)",
        borderColor: "rgba(0,245,212,0.8)",
        borderWidth: 2,
        pointBackgroundColor: "rgba(0,245,212,0.9)",
        pointRadius: 4,
        pointHoverRadius: 6,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        r: {
          min: 0, max: 100,
          grid:      { color: "rgba(0,245,212,0.1)" },
          angleLines:{ color: "rgba(0,245,212,0.1)" },
          pointLabels: {
            color: "rgba(127,168,192,0.8)",
            font: { family: "'DM Mono'", size: 9 },
          },
          ticks: {
            color: "rgba(0,245,212,0.4)",
            font: { family: "'DM Mono'", size: 8 },
            backdropColor: "transparent",
            stepSize: 25,
          },
        },
      },
      plugins: { legend: { display: false } },
    },
  });
}

// ── Entity Heatmap ────────────────────────────────────────────────────────────
function renderHeatmap(rates) {
  heatmapGrid.innerHTML = "";
  const allTypes = VALID_ENTITY_TYPES;

  for (const type of allTypes) {
    const errRate = rates[type] ?? 0;
    const accRate = 1 - errRate;
    const cls = errRate === 0 ? "green" : errRate < 0.1 ? "yellow" : "red";
    const label = errRate === 0 ? "RELIABLE" : errRate < 0.1 ? "MODERATE" : "ISSUES";

    const cell = document.createElement("div");
    cell.className = `heatmap-cell ${cls}`;
    cell.innerHTML = `
      <span class="heatmap-name">${type}</span>
      <span class="heatmap-score">${(accRate * 100).toFixed(0)}%</span>
      <span class="heatmap-label">${label}</span>
    `;
    heatmapGrid.appendChild(cell);
  }
}

// ── Bar Chart (generic) ───────────────────────────────────────────────────────
function renderBarChart(canvasId, inst, ratesObj, keys, colors, saveInst) {
  const ctx = document.getElementById(canvasId).getContext("2d");
  if (inst) inst.destroy();

  const vals = keys.map(k => round4((ratesObj[k] || 0) * 100));

  const newInst = new Chart(ctx, {
    type: "bar",
    data: {
      labels: keys,
      datasets: [{
        data: vals,
        backgroundColor: colors,
        borderColor: colors.map(c => c.replace("0.7","1")),
        borderWidth: 1,
        borderRadius: 4,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      scales: {
        x: {
          min: 0, max: 100,
          grid:  { color: "rgba(255,255,255,0.04)" },
          ticks: { color: "rgba(127,168,192,0.6)", font: { family: "'DM Mono'", size: 9 } },
          border:{ color: "rgba(255,255,255,0.06)" },
        },
        y: {
          grid:  { display: false },
          ticks: { color: "rgba(127,168,192,0.8)", font: { family: "'DM Mono'", size: 9 } },
          border:{ color: "rgba(255,255,255,0.06)" },
        },
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => ` Error rate: ${ctx.raw.toFixed(2)}%`,
          },
          backgroundColor: "rgba(5,13,26,0.95)",
          titleColor: "#00f5d4",
          bodyColor: "#7fa8c0",
          borderColor: "rgba(0,245,212,0.3)",
          borderWidth: 1,
        },
      },
    },
  });
  saveInst(newInst);
}

// ── Core Metrics ──────────────────────────────────────────────────────────────
function renderMetrics(result) {
  const da = result.event_date_accuracy;
  const ac = result.attribute_completeness;
  const tot = result.total_entities;

  setMetric("mBar1", "mVal1", da);
  setMetric("mBar2", "mVal2", ac);

  document.getElementById("mBar3").style.width = "100%";
  document.getElementById("mVal3").textContent = tot;
}

function setMetric(barId, valId, rate) {
  setTimeout(() => {
    document.getElementById(barId).style.width = (rate * 100) + "%";
  }, 100);
  document.getElementById(valId).textContent = (rate * 100).toFixed(1) + "%";
}

// ── Clinical Timeline ─────────────────────────────────────────────────────────
function renderTimeline(timeline) {
  const map = {
    CLINICAL_HISTORY: { el: "tlItemsPast",     max: 12 },
    CURRENT:          { el: "tlItemsCurrent",   max: 12 },
    UPCOMING:         { el: "tlItemsUpcoming",  max: 12 },
    UNCERTAIN:        { el: "tlItemsUncertain", max: 12 },
  };

  for (const [key, cfg] of Object.entries(map)) {
    const container = document.getElementById(cfg.el);
    container.innerHTML = "";
    const items = (timeline[key] || []).slice(0, cfg.max);

    if (!items.length) {
      const none = document.createElement("div");
      none.className = "tl-item"; none.textContent = "—";
      container.appendChild(none);
      continue;
    }
    for (const name of items) {
      const div = document.createElement("div");
      div.className = "tl-item";
      div.textContent = name;
      div.title = name;
      container.appendChild(div);
    }

    // Count badge
    const colEl = container.closest(".tl-col");
    let countEl = colEl.querySelector(".tl-count");
    if (!countEl) {
      countEl = document.createElement("div");
      countEl.className = "tl-count";
      colEl.appendChild(countEl);
    }
    const total = (timeline[key] || []).length;
    countEl.textContent = total > cfg.max ? `+${total - cfg.max} more` : `${total} total`;
  }
}

// ── Reliability Flags ─────────────────────────────────────────────────────────
function renderFlags(flags) {
  if (!flags || !flags.length) {
    flagsPanel.classList.add("hidden");
    return;
  }
  flagsPanel.classList.remove("hidden");
  flagsList.innerHTML = "";

  // Show up to 10
  const shown = flags.slice(0, 10);
  for (const f of shown) {
    const div = document.createElement("div");
    div.className = "flag-item";
    div.innerHTML = `
      <span class="flag-type">${f.type}</span>
      <span class="flag-entity">${f.entity_type}: ${f.entity}</span>
    `;
    div.title = f.detail;
    flagsList.appendChild(div);
  }

  if (flags.length > 10) {
    const more = document.createElement("div");
    more.className = "flag-item";
    more.innerHTML = `<span class="flag-type">+ ${flags.length - 10} more flags</span>`;
    flagsList.appendChild(more);
  }
}

// ── JSON Viewer ───────────────────────────────────────────────────────────────
function renderJson(result) {
  // Remove internal _timeline from output
  const clean = { ...result };
  delete clean._timeline;

  jsonPre.innerHTML = syntaxHighlight(JSON.stringify(clean, null, 2));
}

function syntaxHighlight(json) {
  return json
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
      (match) => {
        if (/^"/.test(match)) {
          return /:$/.test(match)
            ? `<span class="j-key">${match}</span>`
            : `<span class="j-str">${match}</span>`;
        }
        if (/true|false/.test(match)) return `<span class="j-bool">${match}</span>`;
        if (/null/.test(match)) return `<span class="j-null">${match}</span>`;
        return `<span class="j-num">${match}</span>`;
      }
    );
}

function toggleJson() {
  const viewer = document.getElementById("jsonViewer");
  viewer.classList.toggle("expanded");
}

// ── Download Report ───────────────────────────────────────────────────────────
function downloadReport() {
  if (!currentResult) return;
  const clean = { ...currentResult };
  delete clean._timeline;

  const blob = new Blob([JSON.stringify(clean, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = clean.file_name || "evaluation_report.json";
  a.click();
  URL.revokeObjectURL(url);
}
