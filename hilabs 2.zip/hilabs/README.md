# MEDSCAN — Clinical AI Reliability Control Room
### HiLabs Workshop — Evaluation & Reliability Layer

---

## Quick Start

### 1. Clone / Open in VS Code
```bash
code hilabs/
```

### 2. Run Backend Evaluation (CLI)

**Single file:**
```bash
cd backend
python test.py ../test_data/019M72177_N991-796129_20241213/019M72177_N991-796129_20241213.json ../output/test_out.json
```

**Batch all charts:**
```bash
cd backend
python test.py --batch --input-dir ../test_data --output-dir ../output
```

Output JSON files will appear in `output/`. A summary across all charts is written to `output/_summary.json`.

### 3. Open the Frontend

Simply open `frontend/index.html` in any modern browser:
```bash
open frontend/index.html        # macOS
start frontend/index.html       # Windows
xdg-open frontend/index.html    # Linux
```

Then drag and drop any `.json` file from `test_data/` into the upload zone.

No server required — the UI runs evaluation entirely in the browser using the same logic as the Python backend.

---

## Project Structure

```
hilabs/
├── backend/
│   ├── test.py        ← Main entry point (CLI)
│   ├── evaluator.py   ← Core evaluation engine
│   ├── metrics.py     ← Metric computation
│   └── utils.py       ← I/O helpers
│
├── frontend/
│   ├── index.html     ← Control Room UI
│   ├── styles.css     ← Glassmorphism / cyberpunk design
│   └── app.js         ← Charts, drag-drop, evaluation logic
│
├── output/            ← Generated evaluation JSON reports
├── test_data/         ← Input chart folders (9 charts)
├── report.md          ← Full evaluation report
└── requirements.txt
```

---

## Output Schema

Each output JSON follows the required schema:

```json
{
  "file_name": "019M72177_N991-796129_20241213.json",
  "entity_type_error_rate": { "MEDICINE": 0.0, ... },
  "assertion_error_rate":   { "POSITIVE": 0.005, ... },
  "temporality_error_rate": { "UNCERTAIN": 0.091, ... },
  "subject_error_rate":     { "PATIENT": 0.0, ... },
  "event_date_accuracy":    0.8009,
  "attribute_completeness": 0.8469,
  "reliability_flags": [...],
  "total_entities": 462
}
```

---

## Reliability Layers (Bonus Features)

The system implements 3 smart reliability checks:

1. **Missing Attribute Detector** — flags MEDICINE/TEST/VITAL entities with incomplete QA attributes
2. **Suspicious Temporality Detector** — flags critical entities (MEDICINE, PROBLEM) with UNCERTAIN temporality
3. **Cross-Entity Contradiction Detection** — flags entities where `assertion=NEGATIVE` but `temporality=CURRENT/UPCOMING`

---

## No External Dependencies

The backend uses only Python standard library. No pip install needed.
The frontend uses Chart.js loaded from CDN — requires an internet connection for the first load.
