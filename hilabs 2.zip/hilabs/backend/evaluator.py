"""
evaluator.py — Core evaluation engine for clinical AI pipeline outputs.
Analyzes entity JSON files and computes reliability metrics.
"""

import json
import re
from typing import Any
from metrics import MetricsComputer
from utils import load_json, get_qa_relations


# Expected required attributes per entity type
REQUIRED_QA_ATTRS = {
    "MEDICINE": {"STRENGTH", "UNIT", "ROUTE", "FREQUENCY"},
    "TEST": {"TEST_VALUE", "TEST_UNIT"},
    "VITAL_NAME": {"VITAL_NAME_VALUE", "VITAL_NAME_UNIT"},
    "PROCEDURE": set(),
    "PROBLEM": set(),
    "IMMUNIZATION": set(),
    "MEDICAL_DEVICE": set(),
    "MENTAL_STATUS": set(),
    "SDOH": set(),
    "SOCIAL_HISTORY": set(),
}

VALID_ENTITY_TYPES = set(REQUIRED_QA_ATTRS.keys())
VALID_ASSERTIONS = {"POSITIVE", "NEGATIVE", "UNCERTAIN"}
VALID_TEMPORALITIES = {"CURRENT", "CLINICAL_HISTORY", "UPCOMING", "UNCERTAIN"}
VALID_SUBJECTS = {"PATIENT", "FAMILY_MEMBER"}

# Suspicious: if assertion is NEGATIVE but temporality is CURRENT → contradiction
CONTRADICTIONS = [
    ("assertion", "NEGATIVE", "temporality", "CURRENT"),
    ("assertion", "NEGATIVE", "temporality", "UPCOMING"),
]

DATE_REGEX = re.compile(r"\d{4}-\d{2}-\d{2}")


class ClinicalEvaluator:
    """
    Evaluates a list of clinical entities and computes reliability metrics.
    """

    def __init__(self, entities: list):
        self.entities = entities
        self.metrics = MetricsComputer()
        self.flags = []  # reliability layer flags

    def evaluate(self) -> dict:
        """Run full evaluation pipeline and return metrics dict."""
        if not self.entities:
            return self._empty_result()

        entity_type_errors = {}      # {type: [has_error, ...]}
        assertion_errors = {}
        temporality_errors = {}
        subject_errors = {}
        date_scores = []
        completeness_scores = []

        for ent in self.entities:
            etype = ent.get("entity_type", "")
            assertion = ent.get("assertion", "")
            temporality = ent.get("temporality", "")
            subject = ent.get("subject", "")
            qa = ent.get("metadata_from_qa", {})

            # --- Entity type errors ---
            if etype not in VALID_ENTITY_TYPES:
                entity_type_errors.setdefault(etype or "UNKNOWN", []).append(1)
            else:
                entity_type_errors.setdefault(etype, []).append(0)

            # --- Assertion errors ---
            if assertion not in VALID_ASSERTIONS and assertion != "":
                assertion_errors.setdefault(assertion or "MISSING", []).append(1)
            elif assertion in VALID_ASSERTIONS:
                assertion_errors.setdefault(assertion, []).append(0)
            else:
                # Empty assertion — mark as missing/error for non-trivial types
                if etype in ("MEDICINE", "PROBLEM", "PROCEDURE"):
                    assertion_errors.setdefault("POSITIVE", []).append(1)

            # --- Temporality errors ---
            if temporality not in VALID_TEMPORALITIES and temporality != "":
                temporality_errors.setdefault(temporality or "MISSING", []).append(1)
            elif temporality in VALID_TEMPORALITIES:
                temporality_errors.setdefault(temporality, []).append(0)
            else:
                if etype in ("MEDICINE", "PROBLEM"):
                    temporality_errors.setdefault("UNCERTAIN", []).append(1)

            # --- Subject errors ---
            if subject not in VALID_SUBJECTS and subject != "":
                subject_errors.setdefault(subject or "MISSING", []).append(1)
            elif subject in VALID_SUBJECTS:
                subject_errors.setdefault(subject, []).append(0)

            # --- Date accuracy ---
            date_score = self._score_dates(ent, qa)
            date_scores.append(date_score)

            # --- Attribute completeness ---
            comp_score = self._score_completeness(etype, qa)
            completeness_scores.append(comp_score)

            # --- Reliability flags ---
            self._check_contradictions(ent)
            self._check_suspicious_temporality(ent)

        result = {
            "entity_type_error_rate": self.metrics.compute_error_rates(
                entity_type_errors, VALID_ENTITY_TYPES
            ),
            "assertion_error_rate": self.metrics.compute_error_rates(
                assertion_errors, VALID_ASSERTIONS
            ),
            "temporality_error_rate": self.metrics.compute_error_rates(
                temporality_errors, VALID_TEMPORALITIES
            ),
            "subject_error_rate": self.metrics.compute_error_rates(
                subject_errors, VALID_SUBJECTS
            ),
            "event_date_accuracy": round(
                sum(date_scores) / len(date_scores) if date_scores else 0.0, 4
            ),
            "attribute_completeness": round(
                sum(completeness_scores) / len(completeness_scores)
                if completeness_scores
                else 0.0,
                4,
            ),
        }

        # Attach reliability flags as bonus metadata
        result["reliability_flags"] = self.flags
        result["total_entities"] = len(self.entities)
        return result

    # ── private helpers ──────────────────────────────────────────────────────

    def _score_dates(self, ent: dict, qa: dict) -> float:
        """
        Score date accuracy: 1.0 = has a valid date where expected,
        0.0 = date missing or malformed.
        """
        relations = get_qa_relations(qa)
        date_types = {"exact_date", "derived_date"}
        found_dates = [r for r in relations if r.get("entity_type") in date_types]

        if not found_dates:
            # Entities that SHOULD have dates but don't → lower score
            if ent.get("entity_type") in ("PROCEDURE", "TEST", "IMMUNIZATION"):
                return 0.5  # expected but missing → partial penalty
            return 1.0  # not required, no penalty

        # Validate date format
        valid = sum(
            1
            for r in found_dates
            if r.get("entity") and DATE_REGEX.fullmatch(str(r["entity"]).strip())
        )
        return round(valid / len(found_dates), 4)

    def _score_completeness(self, etype: str, qa: dict) -> float:
        """
        Score attribute completeness: fraction of required QA attributes present.
        """
        required = REQUIRED_QA_ATTRS.get(etype, set())
        if not required:
            return 1.0  # no requirements → fully complete

        relations = get_qa_relations(qa)
        present_types = {r.get("entity_type") for r in relations}
        found = required & present_types
        return round(len(found) / len(required), 4)

    def _check_contradictions(self, ent: dict):
        """Flag entities where assertion contradicts temporality."""
        assertion = ent.get("assertion", "")
        temporality = ent.get("temporality", "")
        for a_field, a_val, t_field, t_val in CONTRADICTIONS:
            if ent.get(a_field) == a_val and ent.get(t_field) == t_val:
                self.flags.append({
                    "type": "CONTRADICTION",
                    "entity": ent.get("entity", ""),
                    "entity_type": ent.get("entity_type", ""),
                    "detail": f"{a_field}={a_val} but {t_field}={t_val}",
                })

    def _check_suspicious_temporality(self, ent: dict):
        """Flag entities where temporality is UNCERTAIN for critical types."""
        if (
            ent.get("temporality") == "UNCERTAIN"
            and ent.get("entity_type") in ("MEDICINE", "PROBLEM")
        ):
            self.flags.append({
                "type": "SUSPICIOUS_TEMPORALITY",
                "entity": ent.get("entity", ""),
                "entity_type": ent.get("entity_type", ""),
                "detail": "Critical entity with UNCERTAIN temporality",
            })

    def _empty_result(self) -> dict:
        return {
            "entity_type_error_rate": {t: 0.0 for t in VALID_ENTITY_TYPES},
            "assertion_error_rate": {a: 0.0 for a in VALID_ASSERTIONS},
            "temporality_error_rate": {t: 0.0 for t in VALID_TEMPORALITIES},
            "subject_error_rate": {"PATIENT": 0.0, "FAMILY_MEMBER": 0.0},
            "event_date_accuracy": 0.0,
            "attribute_completeness": 0.0,
            "reliability_flags": [],
            "total_entities": 0,
        }
