"""
test.py — Entry point for the Clinical AI Evaluation Pipeline.

Usage:
    # Evaluate a single file:
    python test.py input.json output.json

    # Batch-evaluate all files in test_data/ and write to output/:
    python test.py --batch

    # Run with custom paths:
    python test.py --batch --input-dir ../test_data --output-dir ../output
"""

import sys
import os
import json
import argparse
from pathlib import Path

# Allow imports from the same directory
sys.path.insert(0, os.path.dirname(__file__))

from evaluator import ClinicalEvaluator
from metrics import MetricsComputer
from utils import load_json, save_json, find_json_in_folder


def evaluate_file(input_path: str, output_path: str) -> dict:
    """
    Evaluate a single clinical JSON file and write the evaluation report.
    Returns the evaluation result dict.
    """
    print(f"  ▶ Evaluating: {input_path}")

    entities = load_json(input_path)
    if not isinstance(entities, list):
        entities = [entities]  # wrap if single object

    evaluator = ClinicalEvaluator(entities)
    result = evaluator.evaluate()

    # Add file metadata
    result["file_name"] = Path(input_path).name

    # Reorder keys to match required schema exactly
    output = {
        "file_name": result["file_name"],
        "entity_type_error_rate": result["entity_type_error_rate"],
        "assertion_error_rate": result["assertion_error_rate"],
        "temporality_error_rate": result["temporality_error_rate"],
        "subject_error_rate": result["subject_error_rate"],
        "event_date_accuracy": result["event_date_accuracy"],
        "attribute_completeness": result["attribute_completeness"],
        # Bonus: reliability flags and totals
        "reliability_flags": result.get("reliability_flags", []),
        "total_entities": result.get("total_entities", 0),
    }

    save_json(output, output_path)
    print(f"  ✔ Output written: {output_path}")
    return output


def batch_evaluate(input_dir: str, output_dir: str) -> list[dict]:
    """
    Batch-evaluate all chart folders inside input_dir.
    Each folder contains a JSON file named after the folder.
    """
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    results = []
    folders = sorted([p for p in input_path.iterdir() if p.is_dir()])

    if not folders:
        # Flat structure: JSON files directly in input_dir
        folders = sorted(input_path.glob("*.json"))

    print(f"\n📂 Found {len(folders)} chart(s) to evaluate in: {input_dir}\n")

    for folder in folders:
        if folder.is_dir():
            json_file = find_json_in_folder(str(folder))
            if not json_file:
                print(f"  ⚠ No JSON found in folder: {folder.name}")
                continue
            out_file = output_path / f"{Path(json_file).name}"
        else:
            json_file = str(folder)
            out_file = output_path / folder.name

        result = evaluate_file(json_file, str(out_file))
        results.append(result)

    # Generate aggregate summary
    mc = MetricsComputer()
    summary = mc.aggregate_summary(results)
    summary_path = output_path / "_summary.json"
    save_json(summary, str(summary_path))
    print(f"\n📊 Aggregate summary written: {summary_path}")
    print(f"   Total files evaluated: {len(results)}")
    print(f"   Total entities analyzed: {summary.get('total_entities', 0)}")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Clinical AI Pipeline Evaluator — HiLabs Workshop"
    )
    parser.add_argument("input", nargs="?", help="Input JSON file path")
    parser.add_argument("output", nargs="?", help="Output JSON file path")
    parser.add_argument("--batch", action="store_true", help="Run batch evaluation")
    parser.add_argument(
        "--input-dir",
        default=os.path.join(os.path.dirname(__file__), "..", "test_data"),
        help="Directory containing chart folders (default: ../test_data)",
    )
    parser.add_argument(
        "--output-dir",
        default=os.path.join(os.path.dirname(__file__), "..", "output"),
        help="Directory for output JSON reports (default: ../output)",
    )

    args = parser.parse_args()

    if args.batch:
        batch_evaluate(args.input_dir, args.output_dir)
    elif args.input and args.output:
        evaluate_file(args.input, args.output)
    else:
        print(__doc__)
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
