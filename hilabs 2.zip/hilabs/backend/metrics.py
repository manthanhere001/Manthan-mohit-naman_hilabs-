"""
metrics.py — Metric computation utilities for clinical AI evaluation.
"""

from typing import Any


class MetricsComputer:
    """Computes normalized error rates from raw error tracking dicts."""

    def compute_error_rates(
        self, error_dict: dict, valid_keys: set
    ) -> dict[str, float]:
        """
        Given a dict of {category: [0/1 error flags]}, compute the error rate
        per category. Only includes keys from valid_keys in the output.

        error flag: 0 = correct, 1 = error
        Returns rates in [0.0, 1.0].
        """
        result = {}
        for key in valid_keys:
            flags = error_dict.get(key, [])
            if not flags:
                result[key] = 0.0
            else:
                result[key] = round(sum(flags) / len(flags), 4)

        # Check for unknown types → distribute as errors into closest category
        for key, flags in error_dict.items():
            if key not in valid_keys and flags:
                # Aggregate unknown errors; assign to first valid key as reference
                pass  # We capture totals in the main report

        return result

    def aggregate_summary(self, all_results: list[dict]) -> dict:
        """
        Aggregate evaluation results across multiple files into summary stats.
        Returns mean error rates across all files.
        """
        if not all_results:
            return {}

        # Collect all keys
        keys_entity = set()
        keys_assertion = set()
        keys_temporality = set()
        keys_subject = set()

        for r in all_results:
            keys_entity.update(r.get("entity_type_error_rate", {}).keys())
            keys_assertion.update(r.get("assertion_error_rate", {}).keys())
            keys_temporality.update(r.get("temporality_error_rate", {}).keys())
            keys_subject.update(r.get("subject_error_rate", {}).keys())

        def mean_rates(key_group: str, keys: set) -> dict:
            result = {}
            for k in sorted(keys):
                vals = [
                    r.get(key_group, {}).get(k, 0.0)
                    for r in all_results
                    if k in r.get(key_group, {})
                ]
                result[k] = round(sum(vals) / len(vals), 4) if vals else 0.0
            return result

        return {
            "entity_type_error_rate": mean_rates("entity_type_error_rate", keys_entity),
            "assertion_error_rate": mean_rates("assertion_error_rate", keys_assertion),
            "temporality_error_rate": mean_rates(
                "temporality_error_rate", keys_temporality
            ),
            "subject_error_rate": mean_rates("subject_error_rate", keys_subject),
            "event_date_accuracy": round(
                sum(r.get("event_date_accuracy", 0.0) for r in all_results)
                / len(all_results),
                4,
            ),
            "attribute_completeness": round(
                sum(r.get("attribute_completeness", 0.0) for r in all_results)
                / len(all_results),
                4,
            ),
            "total_files": len(all_results),
            "total_entities": sum(r.get("total_entities", 0) for r in all_results),
        }
